## Thanks for Everything 
### We will always remember you..

- [Yusuf Usta](https://github.com/yusufusta)
- [@fusufs](https://t.me/fusufs)

<p align="center">
  <a href="https://github.com/phaticusthiccy/WhatsAsenaDuplicated/fork">
    <img src="https://img.shields.io/github/forks/phaticusthiccy/WhatsAsenaDuplicated?label=Fork&style=social">
    
  </a>
  <a href="https://github.com/phaticusthiccy/WhatsAsenaDuplicated/stargazers">
    <img src="https://img.shields.io/github/stars/phaticusthiccy/WhatsAsenaDuplicated?style=social">
  </a>
  <a href="https://github.com/phaticusthiccy/WhatsAsenaDuplicated/commits/master">
    <img src="https://img.shields.io/github/commit-activity/m/phaticusthiccy/WhatsAsenaDuplicated?style=social">
  </a>
</p>

<p align="center">
  <a href="httsp://github.com/phaticusthiccy/WhatsAsenaDuplicated">
    <img src="https://img.shields.io/github/repo-size/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=Repo%20Size&style=plastic">

  </a>
  <a href="httsp://github.com/phaticusthiccy/WhatsAsenaDuplicated">
    <img src="https://img.shields.io/codefactor/grade/github/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=Code%20Quality&style=plastic">

  </a>
  <a href="https://github.com/phaticusthiccy/WhatsAsenaDuplicated/blob/master/LICENSE">
    <img src="https://img.shields.io/github/license/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=Lisance&style=plastic">

  </a>
  <a href="https://github.com/phaticusthiccy/WhatsAsenaDuplicated">
    <img src="https://img.shields.io/github/languages/top/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=Javascript&style=plastic">

  </a>
  <a href="https://github.com/phaticusthiccy">
    <img src="https://img.shields.io/static/v1?label=Author&message=Thiccy&color=purple&style=plastic">

  </a>
  <a href="https://t.me/asenaremaster">
    <img src="https://img.shields.io/badge/Telegram-Asena%20Remaster-purple&style=plastic">

  </a>
</p>

```
Asena; Asena UserBot, WhatsAsena yazılımı temsil eden adlardır, yazının devamında birbiri yerine kullanılabilir.

WhatsAsena - Asena Userbot Açık Kaynaklı geliştirmeye açık bir yazılımdır. 
Yanlış ve amacı dışında kullanımdan doğabilecek tüm sonuçlardan kullanıcı sorumludur. 
Açık kaynaklı bir proje olduğundan isteyen herkes yazılımı kopyalayıp eklemeler çıkarmalar yapabilir,
kendi özelleştirdiği biçimde kullanabilir. Ayrıca eklenti (plugin) desteği, 
orijinal yazılıma kullanıcıların kendi yazdıkları eklentileri yükleyerek istedikleri 
biçimde kullanmaları özelliğini sağlar.
Kullanımı tamamen kullanıcının sorumluluğundadır.
Botu amacı dışında kullanmak, açık bir şekilde yasaklanmanıza sebeb olur.
Asena Userbot yalnızca bir altyapıdır. Nasıl sonradan yüklenen programlarla 
yapılan işlerden işletim sistemi sorumlu değilse, 
WhatsAsena da kullanıcıların kullanım amacı ve yönteminden sorumlu değildir.
WhatsAsena'yı para karşılığı pazarlamak, kullanıma sunmak yahut herhangi bir maddi değere sahip
birşey ile satışa sunmak kesinlikle yasaktır. Doğabilecek tüm yasal soruşturmalardan
kullanıcı sorumludur.

WhatsAsena - Asena Userbot is Open Source software open to development. 
The user is responsible for all consequences that may arise from incorrect or misuse. 
Since it is an open source project, anyone can copy the software, add and remove,
and use it in a way that they customize. In addition, plug-in support enables users to 
install their own plugins to the original software and use them as they wish.
Using the bot out of purpose will explicitly ban you.
Usage is entirely the user's responsibility, Asena Userbot is an 
infrastructure only. Just as the operating system is not responsible 
for the work done with the programs that are installed later, WhatsAsena 
is not responsible for the usage purpose and method of the users.
Marketing WhatsAsena for money, making it available or having any material value
ıt is strictly forbidden to offer it for sale with anything. All legal investigations that may arise
the user is responsible.
```

<div align="center">
  <img src="https://i.hizliresim.com/mm1NBs.jpg" width="200" height="200">
  <h1>🐺 WhatsAsena Duplicated</h1>
</div>
<p align="center">
    WhatsAsena project - Makes it easy and fun to use Whatsapp. Also first userbot for Whatsapp.
    <br>
        <a href="https://t.me/WHATSASENA">Telegram Channel</a> |
        <a href="https://t.me/AsenaSupport">Telegram Group</a> |
        <a href="https://t.me/asenaremaster">New Support Group</a> |
        <a href="https://t.me/unofficialplugin">New Plugin Channel</a> |
    <br>
</p>

----
![Docker Pulls](https://img.shields.io/docker/pulls/fusuf/whatsasena?style=flat-square) ![Docker Image Size (latest by date)](https://img.shields.io/docker/image-size/fusuf/whatsasena?style=flat-square)

## 📢 Guide
> [Also for support & help please come our Telegram group.](https://t.me/AsenaSupport) (Legacy)

> [New support & help group.](https://t.me/asenaremaster) (New)

> [Install Guide/Kurulum Yardımcısı/Qurulum Müavin](https://github.com/phaticusthiccy/WhatsAsenaDuplicated/wiki)

## 🔎 What is WhatsAsena?
**WhatsAsena,** is a WhatsApp helper bot written by [Yusuf Usta](https://github.com/Quiec) and edited by [Phaticusthiccy](https://github.com/phaticusthiccy). Does not log into your account It is written on WhatsApp Web API.

## Setup
### Very Simple Method
`Soon as Possible...`

### Simple Method

[![Run on Repl.it](https://repl.it/badge/github/phaticusthiccy/WhatsAsenaDuplicated)](https://repl.it/@phaticusthiccy/WhatsAsena-QR)

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/phaticusthiccy/WhatsAsenaDuplicated)

### The Hard Method
```js
$ git clone https://github.com/phaticusthiccy/WhatsAsenaDuplicated.git
$ cd WhatsAsenaDuplicated
$ npm i
$ nano Config.env
// Config.env oluşturun ve düzenleyin.
// Config.env create and edit.
$ node bot.js
```

##

### ⚒️ Setup Wiki - Kurulum [Tam Anlatım]
[![Setup - Kurulum](https://img.icons8.com/clouds/300/000000/settings.png)](https://github.com/phaticusthiccy/WhatsAsenaDuplicated/wiki)

##

## F.A.Q
Answer a few frequently asked questions;
### Can you read my messages?
This project is open source so all the codes are clear. Neither less nor more; you can look what you want. **We absolutely do not have access to your accounts.**

### What about our security?
If you are concerned about security, you can install it on your own computer. If you think someone else has captured your data, simply click on **Whatsapp> Three Dots> Whatsapp Web> Logout** from all sessions button.

### Is it paid?
**Of course not.** It will never happen. But you can donate to us. You can reach me via [Telegram](https://t.me/fusuf) .

### What does Asena mean?
[Asena](https://tr.wikipedia.org/wiki/Asena), comes from Turkish mythology. According to Turkish mythology, Asena is a she-wolf that plays an important role.

##

### ⚠️ Warning! 
```
Due to Userbot; Your WhatsApp account may be banned.
This is an open source project, you are responsible for everything you do. 
Absolutely, Asena executives do not accept responsibility.
By establishing the Asena, you are deemed to have accepted these responsibilities.
```

## Developers

[![Yusuf Usta](https://github.com/yusufusta.png?size=100)](https://www.fusuf.codes) | [![Phaticusthiccy](https://github.com/phaticusthiccy.png?size=100)](https://github.com/phaticusthiccy) | [![Alperen Ç](https://github.com/xacnio.png?size=100)](https://github.com/xacnio) | [![Justin Thoms](https://github.com/justinthoms.png?size=100)](https://github.com/justinthoms) | [![CW4RR10R](https://github.com/CW4RR10R.png?size=100)](https://github.com/CW4RR10R)
----|----|----|----|----
[Yusuf Usta](https://t.me/fusufs) | [Phaticusthiccy](https://github.com/phaticusthiccy) | [Alperen Ç](https://t.me/xacnio) | [justinthoms](https://t.me/Mr_justinthomas) | [CW4RR10R](https://github.com/CW4RR10R)
Author, Base, Bug Fixes, Modules | Developer, Base, Bug Fixes, Modules | Bug Fixes, Modules, Idea | Modules, Idea | Modules

## Thanks To
- [@adiwajshing](https://github.com/adiwajshing) for coded [Baileys](https://github.com/adiwajshing/Baileys) 
- [@itacirgabral](https://github.com/itacirgabral) for helps
- `Ikarus#7808 (Discord)` for helps
- [@Unique_hunter](https://t.me/Unique_hunter) for helps and ideas
- Translators

## License
This project is protected by `GNU General Public Licence v3.0` license.

### Disclaimer
`WhatsApp` name, its variations and the logo are registered trademarks of Facebook. We have nothing to do with the registered trademark
